import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;



public class WeatherApp {
	
	private static JsonObject getWeatherData()throws IOException{
		URL url=new URL("https://samples.openweathermap.org/data/2.5/forecast/hourly?q=London,us&appid=b6907d289e10d714a6e88b30761fae22");
		HttpURLConnection conn=(HttpURLConnection) url.openConnection();
		conn.setRequestMethod("GET");
		conn.setRequestProperty("Accept","application/json");
		
		if(conn.getResponseCode()!=200) {
			System.out.println("failed to get weather data.");
			return null;
		}
		
		BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
        JsonParser parser = new JsonParser();
        JsonObject jsonData = parser.parse(br).getAsJsonObject();

        conn.disconnect();
        return jsonData;
	}
	 private static double getWeatherByDate(JsonObject data, String date) {
		 JsonArray list=data.getAsJsonArray("list");
		 for(int i=0;i<list.size();i++) {
			 JsonObject entry =list.get(i).getAsJsonObject();
			 String dtTxt=entry.get("dt_txt").getAsString();
			 if(dtTxt.contains(date)) {
				 JsonObject main=entry.getAsJsonObject("main");
				 return main.get("temp").getAsDouble();
			 }
		 }
		return Double.NaN;
	 }
	 
	 private static double getWindSpeedByDate(JsonObject data,String date) {
		 JsonArray list=data.getAsJsonArray("list");
		 for(int i=0;i<list.size();i++) {
			 JsonObject entry=list.get(i).getAsJsonObject();
			 String dtTxt =entry.get("dt_txt").getAsString();
			 if(dtTxt.contains(date)) {
				 JsonObject wind=entry.getAsJsonObject("wind");
				 return wind.get("speed").getAsDouble();
			 }
		 }
		 return Double.NaN;
	 }
	 
	 private static double getPressureByDate(JsonObject data,String date) {
		 JsonArray list=data.getAsJsonArray("list");
		 for(int i=0;i<list.size();i++) {
			 JsonObject entry=list.get(i).getAsJsonObject();
			 String dtTxt = entry.get("dt_txt").getAsString();
			 if(dtTxt.contains(date)) {
				 JsonObject main=entry.getAsJsonObject("main");
				 return main.get("pressure").getAsDouble();
			 }
		 }
		 return Double.NaN;
	 }
	 
	 public static void main(String[] args) throws IOException{
		 JsonObject data=getWeatherData();
		 if(data==null) {
			 return;
		 }
		 BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		 while(true) {
			 System.out.println("\nOptions:");
	            System.out.println("1. Get weather");
	            System.out.println("2. Get Wind Speed");
	            System.out.println("3. Get Pressure");
	            System.out.println("0. Exit");

	            System.out.print("Enter your choice: ");
	            int choice = Integer.parseInt(br.readLine());
	            
	            if (choice == 0) {
	                System.out.println("Terminating the program.");
	                break;
	            } else if (choice == 1) {
	                System.out.print("Enter the date (yyyy-mm-dd): ");
	                String date = br.readLine();
	                double temp = getWeatherByDate(data, date);
	                if (!Double.isNaN(temp)) {
	                    System.out.println("Temperature on " + date + ": " + temp);
	                } else {
	                    System.out.println("No data found for the given date.");
	                }
	            } else if (choice == 2) {
	                System.out.print("Enter the date (yyyy-mm-dd): ");
	                String date = br.readLine();
	                double windSpeed = getWindSpeedByDate(data, date);
	                if (!Double.isNaN(windSpeed)) {
	                    System.out.println("Wind speed on " + date + ": " + windSpeed);
	                } else {
	                    System.out.println("No data found for the given date.");
	                }
	            } else if (choice == 3) {
	                System.out.print("Enter the date (yyyy-mm-dd): ");
	                String date = br.readLine();
	                double pressure = getPressureByDate(data, date);
	                if (!Double.isNaN(pressure)) {
	                    System.out.println("Pressure on " + date + ": " + pressure);
	                } else {
	                    System.out.println("No data found for the given date.");
	                }
	            } else {
	                System.out.println("Invalid choice. Please try again.");
	            }
		 }

	 }

}
